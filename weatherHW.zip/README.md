# weather
Code displays a simple HTML page to obtain the zip code from the user and then uses zip code to obtain weather from Open Weather Map API
Note: Requires API Token Key by registration with site below. Free for basic usage
https://openweathermap.org/api
